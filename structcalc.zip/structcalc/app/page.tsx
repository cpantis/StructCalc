"use client";

import { useState } from "react";

const JUDETE_ZAPADA: Record<string, number> = {
  "Alba": 1.5, "Arad": 1.5, "Arges": 2.0, "Bacau": 2.0, "Bihor": 1.5,
  "Bistrita-Nasaud": 2.0, "Botosani": 2.0, "Brasov": 2.5, "Braila": 1.5,
  "Buzau": 2.0, "Caras-Severin": 1.5, "Calarasi": 1.5, "Cluj": 2.0,
  "Constanta": 1.5, "Covasna": 2.5, "Dambovita": 2.0, "Dolj": 1.5,
  "Galati": 1.5, "Giurgiu": 1.5, "Gorj": 1.5, "Harghita": 2.5,
  "Hunedoara": 2.0, "Ialomita": 1.5, "Iasi": 2.0, "Ilfov": 1.5,
  "Maramures": 2.0, "Mehedinti": 1.5, "Mures": 2.0, "Neamt": 2.5,
  "Olt": 1.5, "Prahova": 2.0, "Satu Mare": 1.5, "Salaj": 1.5,
  "Sibiu": 2.0, "Suceava": 2.5, "Teleorman": 1.5, "Timis": 1.5,
  "Tulcea": 1.5, "Vaslui": 2.0, "Valcea": 2.0, "Vrancea": 2.0, "Bucuresti": 1.5
};

const JUDETE_VANT: Record<string, number> = {
  "Alba": 0.4, "Arad": 0.5, "Arges": 0.4, "Bacau": 0.5, "Bihor": 0.5,
  "Bistrita-Nasaud": 0.4, "Botosani": 0.5, "Brasov": 0.4, "Braila": 0.5,
  "Buzau": 0.5, "Caras-Severin": 0.4, "Calarasi": 0.5, "Cluj": 0.4,
  "Constanta": 0.6, "Covasna": 0.4, "Dambovita": 0.4, "Dolj": 0.5,
  "Galati": 0.5, "Giurgiu": 0.5, "Gorj": 0.4, "Harghita": 0.4,
  "Hunedoara": 0.4, "Ialomita": 0.5, "Iasi": 0.5, "Ilfov": 0.5,
  "Maramures": 0.4, "Mehedinti": 0.5, "Mures": 0.4, "Neamt": 0.4,
  "Olt": 0.5, "Prahova": 0.5, "Satu Mare": 0.5, "Salaj": 0.4,
  "Sibiu": 0.4, "Suceava": 0.4, "Teleorman": 0.5, "Timis": 0.5,
  "Tulcea": 0.6, "Vaslui": 0.5, "Valcea": 0.4, "Vrancea": 0.5, "Bucuresti": 0.5
};

interface SeismicData { ag: number; Tc: number; oras: string; }
const JUDETE_SEISMIC: Record<string, SeismicData> = {
  "Alba": { ag: 0.15, Tc: 0.7, oras: "Alba Iulia" },
  "Arad": { ag: 0.10, Tc: 0.7, oras: "Arad" },
  "Arges": { ag: 0.25, Tc: 1.0, oras: "Pitesti" },
  "Bacau": { ag: 0.30, Tc: 0.7, oras: "Bacau" },
  "Bihor": { ag: 0.10, Tc: 0.7, oras: "Oradea" },
  "Bistrita-Nasaud": { ag: 0.15, Tc: 0.7, oras: "Bistrita" },
  "Botosani": { ag: 0.20, Tc: 0.7, oras: "Botosani" },
  "Brasov": { ag: 0.25, Tc: 0.7, oras: "Brasov" },
  "Braila": { ag: 0.30, Tc: 1.0, oras: "Braila" },
  "Buzau": { ag: 0.35, Tc: 1.0, oras: "Buzau" },
  "Caras-Severin": { ag: 0.15, Tc: 0.7, oras: "Resita" },
  "Calarasi": { ag: 0.25, Tc: 1.6, oras: "Calarasi" },
  "Cluj": { ag: 0.10, Tc: 0.7, oras: "Cluj-Napoca" },
  "Constanta": { ag: 0.15, Tc: 1.0, oras: "Constanta" },
  "Covasna": { ag: 0.25, Tc: 0.7, oras: "Sfantu Gheorghe" },
  "Dambovita": { ag: 0.25, Tc: 1.0, oras: "Targoviste" },
  "Dolj": { ag: 0.20, Tc: 1.0, oras: "Craiova" },
  "Galati": { ag: 0.25, Tc: 1.0, oras: "Galati" },
  "Giurgiu": { ag: 0.20, Tc: 1.6, oras: "Giurgiu" },
  "Gorj": { ag: 0.15, Tc: 0.7, oras: "Targu Jiu" },
  "Harghita": { ag: 0.20, Tc: 0.7, oras: "Miercurea Ciuc" },
  "Hunedoara": { ag: 0.10, Tc: 0.7, oras: "Deva" },
  "Ialomita": { ag: 0.25, Tc: 1.6, oras: "Slobozia" },
  "Iasi": { ag: 0.25, Tc: 0.7, oras: "Iasi" },
  "Ilfov": { ag: 0.30, Tc: 1.6, oras: "Buftea" },
  "Maramures": { ag: 0.15, Tc: 0.7, oras: "Baia Mare" },
  "Mehedinti": { ag: 0.15, Tc: 0.7, oras: "Drobeta-Turnu Severin" },
  "Mures": { ag: 0.15, Tc: 0.7, oras: "Targu Mures" },
  "Neamt": { ag: 0.30, Tc: 0.7, oras: "Piatra Neamt" },
  "Olt": { ag: 0.20, Tc: 1.0, oras: "Slatina" },
  "Prahova": { ag: 0.30, Tc: 1.0, oras: "Ploiesti" },
  "Satu Mare": { ag: 0.10, Tc: 0.7, oras: "Satu Mare" },
  "Salaj": { ag: 0.10, Tc: 0.7, oras: "Zalau" },
  "Sibiu": { ag: 0.15, Tc: 0.7, oras: "Sibiu" },
  "Suceava": { ag: 0.20, Tc: 0.7, oras: "Suceava" },
  "Teleorman": { ag: 0.20, Tc: 1.0, oras: "Alexandria" },
  "Timis": { ag: 0.20, Tc: 0.7, oras: "Timisoara" },
  "Tulcea": { ag: 0.20, Tc: 1.0, oras: "Tulcea" },
  "Vaslui": { ag: 0.30, Tc: 0.7, oras: "Vaslui" },
  "Valcea": { ag: 0.20, Tc: 1.0, oras: "Ramnicu Valcea" },
  "Vrancea": { ag: 0.40, Tc: 0.7, oras: "Focsani" },
  "Bucuresti": { ag: 0.30, Tc: 1.6, oras: "Bucuresti" }
};

interface Mat { id: string; name: string; density: number; unit: string; }
const MATS: Mat[] = [
  { id: "m1", name: "Beton armat", density: 25, unit: "kN/m\u00b3" },
  { id: "m2", name: "Otel", density: 78.5, unit: "kN/m\u00b3" },
  { id: "m3", name: "Zidarie caramida", density: 18, unit: "kN/m\u00b3" },
  { id: "m4", name: "Zidarie BCA", density: 7, unit: "kN/m\u00b3" },
  { id: "m5", name: "Mortar ciment", density: 21, unit: "kN/m\u00b3" },
  { id: "m6", name: "Sapa ciment", density: 22, unit: "kN/m\u00b3" },
  { id: "m7", name: "Lemn (rasinoase)", density: 5, unit: "kN/m\u00b3" },
  { id: "m8", name: "Pardoseala ceramica", density: 22, unit: "kN/m\u00b3" },
  { id: "m9", name: "Hidroizolatie bituminoasa", density: 12, unit: "kN/m\u00b3" },
  { id: "m10", name: "Termoizolatie polistiren", density: 0.3, unit: "kN/m\u00b3" },
  { id: "m11", name: "Tabla cutata", density: 0.12, unit: "kN/m\u00b2" },
  { id: "m12", name: "Tigla ceramica", density: 0.50, unit: "kN/m\u00b2" }
];

const CLS_IMP = [
  { cls: "I", gamma: 1.4, desc: "Cladiri esentiale (spitale, pompieri)" },
  { cls: "II", gamma: 1.2, desc: "Cladiri aglomerate (scoli, sali)" },
  { cls: "III", gamma: 1.0, desc: "Cladiri curente (locuinte, birouri)" },
  { cls: "IV", gamma: 0.8, desc: "Cladiri temporare, agricole" }
];

const CAT_TEREN = [
  { cat: "0", z0: 0.003, zmin: 1, desc: "Mare deschisa, lacuri" },
  { cat: "I", z0: 0.01, zmin: 1, desc: "Teren plat, vegetatie rara" },
  { cat: "II", z0: 0.05, zmin: 2, desc: "Vegetatie joasa, obstacole izolate" },
  { cat: "III", z0: 0.3, zmin: 5, desc: "Vegetatie/cladiri regulate (suburbii)" },
  { cat: "IV", z0: 1.0, zmin: 10, desc: "Minim 15% acoperit cu cladiri >15m" }
];

const Ic = {
  Building: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 21h18M9 8h1M9 12h1M9 16h1M14 8h1M14 12h1M14 16h1M5 21V5a2 2 0 012-2h10a2 2 0 012 2v16"/></svg>,
  Snow: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2v20M2 12h20M4.93 4.93l14.14 14.14M19.07 4.93L4.93 19.07"/></svg>,
  Wind: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9.59 4.59A2 2 0 1111 8H2m10.59 11.41A2 2 0 1014 16H2m15.73-8.27A2.5 2.5 0 1119.5 12H2"/></svg>,
  Seismic: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="2 12 6 12 8 4 12 20 16 8 18 12 22 12"/></svg>,
  Layers: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>,
  Combo: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/></svg>,
  Plus: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  Trash: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>,
  Dl: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
};

const Inp = ({ label, value, onChange, type="text", suffix, small, disabled }: any) => (
  <div style={{ display:"flex", flexDirection:"column", gap:4, flex: small?"0 0 auto":1 }}>
    {label && <label style={{ fontSize:11, color:"#94a3b8", fontWeight:500 }}>{label}</label>}
    <div style={{ display:"flex", alignItems:"center", gap:4 }}>
      <input type={type} value={value} onChange={(e: any) => onChange(type==="number"?parseFloat(e.target.value)||0:e.target.value)} disabled={disabled}
        style={{ background: disabled?"#1e293b":"#0f172a", border:"1px solid #334155", borderRadius:6, padding:"8px 12px", color:"#e2e8f0", fontSize:13, width: small?80:"100%", outline:"none", opacity: disabled?0.6:1 }} />
      {suffix && <span style={{ fontSize:12, color:"#64748b", whiteSpace:"nowrap" }}>{suffix}</span>}
    </div>
  </div>
);

const Sel = ({ label, value, onChange, options }: any) => (
  <div style={{ display:"flex", flexDirection:"column", gap:4, flex:1 }}>
    {label && <label style={{ fontSize:11, color:"#94a3b8", fontWeight:500 }}>{label}</label>}
    <select value={value} onChange={(e: any) => onChange(e.target.value)}
      style={{ background:"#0f172a", border:"1px solid #334155", borderRadius:6, padding:"8px 12px", color:"#e2e8f0", fontSize:13, outline:"none" }}>
      {options.map((o: any) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  </div>
);

const Card = ({ children, title, accent }: any) => (
  <div style={{ background:"#1e293b", borderRadius:10, border:"1px solid #334155", borderTop: accent?`3px solid ${accent}`:undefined, overflow:"hidden" }}>
    {title && <div style={{ padding:"12px 16px", borderBottom:"1px solid #334155", fontWeight:600, fontSize:14, color:"#f1f5f9" }}>{title}</div>}
    <div style={{ padding:16 }}>{children}</div>
  </div>
);

const Btn = ({ children, onClick, variant="primary", small, disabled, style: ext }: any) => {
  const s: any = { primary:{background:"#3b82f6",color:"#fff"}, danger:{background:"#ef4444",color:"#fff"}, ghost:{background:"transparent",color:"#94a3b8",border:"1px solid #334155"}, success:{background:"#10b981",color:"#fff"} };
  return <button onClick={onClick} disabled={disabled} style={{ ...s[variant], borderRadius:6, border:"none", cursor: disabled?"not-allowed":"pointer", padding: small?"4px 10px":"8px 16px", fontSize: small?12:13, fontWeight:500, display:"inline-flex", alignItems:"center", gap:6, opacity: disabled?0.5:1, transition:"all 0.15s", ...ext }}>{children}</button>;
};

const Badge = ({ children, color="#3b82f6" }: any) => <span style={{ background:color+"20", color, fontSize:11, fontWeight:600, padding:"2px 8px", borderRadius:20 }}>{children}</span>;

interface Layer { id:string; material:string; density:number; thickness:number; unit:string; }

export default function StructCalc() {
  const [tab, setTab] = useState("project");
  const [proj, setProj] = useState({ name:"", judet:"Bucuresti", tipCladire:"locuinta", H:10, L:20, B:12, nrEtaje:3, clasaImp:"III" });
  const [layers, setLayers] = useState<Layer[]>([
    { id:"l1", material:"Pardoseala ceramica", density:22, thickness:0.02, unit:"kN/m\u00b3" },
    { id:"l2", material:"Sapa ciment", density:22, thickness:0.05, unit:"kN/m\u00b3" },
    { id:"l3", material:"Beton armat", density:25, thickness:0.15, unit:"kN/m\u00b3" }
  ]);
  const [sP, setSP] = useState({ roofType:"plat", mu:0.8, Ce:1.0, Ct:1.0 });
  const [wP, setWP] = useState({ catTeren:"III", co:1.0 });
  const [eP, setEP] = useState({ q:3.5, eta:1.0, beta0:2.5 });

  const s0k = JUDETE_ZAPADA[proj.judet]||1.5;
  const qb = JUDETE_VANT[proj.judet]||0.5;
  const sz = JUDETE_SEISMIC[proj.judet]||{ag:0.20,Tc:1.0,oras:""};
  const gI = CLS_IMP.find(c=>c.cls===proj.clasaImp)?.gamma||1.0;
  const totalG = layers.reduce((s,l)=>s+(l.unit==="kN/m\u00b2"?l.density:l.density*l.thickness),0);
  const snowL = sP.mu*sP.Ce*sP.Ct*s0k;
  const tc = CAT_TEREN.find(c=>c.cat===wP.catTeren)||CAT_TEREN[2];
  const zz = Math.max(proj.H,tc.zmin);
  const kr = 0.19*Math.pow(tc.z0/0.05,0.07);
  const crz = kr*Math.log(zz/tc.z0);
  const qpz = qb*(1+7*kr/(crz*wP.co))*crz*crz*wP.co*wP.co;

  const getSe = (T:number) => {
    const {ag,Tc}=sz, Tb=Tc/3, Td=2, b0=eP.beta0, eta=eP.eta;
    if(T===0) return ag*b0*gI;
    if(T<Tb) return ag*gI*(1+(b0*eta-1)*T/Tb);
    if(T<=Tc) return ag*b0*eta*gI;
    if(T<=Td) return ag*b0*eta*gI*(Tc/T);
    return ag*b0*eta*gI*(Tc*Td/(T*T));
  };

  const G=totalG,S=snowL,W=qpz;
  const combos = {
    uls:[
      {name:"ULS 1: G + S (dominant)",value:1.35*G+1.5*S+1.5*0.6*W,formula:`1.35\u00d7${G.toFixed(2)} + 1.5\u00d7${S.toFixed(2)} + 1.5\u00d70.6\u00d7${W.toFixed(3)}`},
      {name:"ULS 2: G + W (dominant)",value:1.35*G+1.5*W+1.5*0.5*S,formula:`1.35\u00d7${G.toFixed(2)} + 1.5\u00d7${W.toFixed(3)} + 1.5\u00d70.5\u00d7${S.toFixed(2)}`},
      {name:"ULS 3: G minim",value:G,formula:`1.0\u00d7${G.toFixed(2)}`}
    ],
    sls_f:[
      {name:"SLS Frecventa (S dom.)",value:G+0.2*S,formula:`${G.toFixed(2)} + 0.2\u00d7${S.toFixed(2)}`},
      {name:"SLS Frecventa (W dom.)",value:G+0.2*W,formula:`${G.toFixed(2)} + 0.2\u00d7${W.toFixed(3)}`}
    ],
    sls_q:[{name:"SLS Quasi-permanenta",value:G,formula:`${G.toFixed(2)}`}]
  };

  const exportR = () => {
    const l = [
      "RAPORT INCARCARI STRUCTURALE","=".repeat(50),
      `Proiect: ${proj.name||"\u2014"}`,`Judet: ${proj.judet} | Oras: ${sz.oras}`,
      `Dim: H=${proj.H}m, L=${proj.L}m, B=${proj.B}m, ${proj.nrEtaje} etaje`,
      `Clasa: ${proj.clasaImp} (gI=${gI})`,"",
      "--- G ---",...layers.map(x=>`  ${x.material}: ${(x.unit==="kN/m\u00b2"?x.density:x.density*x.thickness).toFixed(3)} kN/m\u00b2`),
      `  TOTAL G = ${totalG.toFixed(2)} kN/m\u00b2`,"",
      "--- ZAPADA (CR 1-1-3) ---",`  s0k=${s0k} | mu=${sP.mu} | Ce=${sP.Ce} | Ct=${sP.Ct}`,`  s = ${snowL.toFixed(2)} kN/m\u00b2`,"",
      "--- VANT (CR 1-1-4) ---",`  qb=${qb} | cat=${wP.catTeren} | co=${wP.co}`,`  qp(z) = ${qpz.toFixed(3)} kN/m\u00b2`,"",
      "--- SEISMIC (P100-1/2013) ---",`  ag=${sz.ag}g | Tc=${sz.Tc}s | gI=${gI}`,`  q=${eP.q} | Sd,max=${(sz.ag*eP.beta0*gI/eP.q).toFixed(3)}g`,"",
      "--- ULS ---",...combos.uls.map(c=>`  ${c.name}: ${c.value.toFixed(2)} kN/m\u00b2`),"",
      "--- SLS ---",...combos.sls_f.map(c=>`  ${c.name}: ${c.value.toFixed(2)} kN/m\u00b2`),
      ...combos.sls_q.map(c=>`  ${c.name}: ${c.value.toFixed(2)} kN/m\u00b2`),"",
      `Generat cu StructCalc | ${new Date().toLocaleDateString("ro-RO")}`
    ];
    const b=new Blob([l.join("\n")],{type:"text/plain"});
    const a=document.createElement("a");a.href=URL.createObjectURL(b);
    a.download=`structcalc_${proj.name||"raport"}.txt`;a.click();
  };

  const Spectrum = () => {
    const pts:{T:number;Sa:number}[]=[];
    for(let T=0;T<=4;T+=0.05) pts.push({T,Sa:getSe(T)});
    const mx=Math.max(...pts.map(p=>p.Sa));
    const w=500,h=200,px=50,py=20,cw=w-2*px,ch=h-2*py;
    const d=pts.map((p,i)=>{const x=px+(p.T/4)*cw,y=py+ch-(p.Sa/(mx*1.1))*ch;return `${i===0?"M":"L"}${x},${y}`;}).join(" ");
    return (
      <svg viewBox={`0 0 ${w} ${h}`} style={{width:"100%",maxWidth:500}}>
        <defs><linearGradient id="sg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#ef4444" stopOpacity="0.3"/><stop offset="100%" stopColor="#ef4444" stopOpacity="0"/></linearGradient></defs>
        <path d={d+` L${px+cw},${py+ch} L${px},${py+ch} Z`} fill="url(#sg)"/>
        <path d={d} fill="none" stroke="#ef4444" strokeWidth="2"/>
        <line x1={px} y1={py+ch} x2={px+cw} y2={py+ch} stroke="#475569" strokeWidth="1"/>
        <line x1={px} y1={py} x2={px} y2={py+ch} stroke="#475569" strokeWidth="1"/>
        {[0,1,2,3,4].map(t=><text key={t} x={px+(t/4)*cw} y={h-2} fill="#94a3b8" fontSize="10" textAnchor="middle">{t}s</text>)}
        <text x={15} y={py+ch/2} fill="#94a3b8" fontSize="10" textAnchor="middle" transform={`rotate(-90,15,${py+ch/2})`}>Se (g)</text>
        <line x1={px+(sz.Tc/3/4)*cw} y1={py} x2={px+(sz.Tc/3/4)*cw} y2={py+ch} stroke="#94a3b8" strokeWidth="1" strokeDasharray="2"/>
        <text x={px+(sz.Tc/3/4)*cw} y={py-4} fill="#94a3b8" fontSize="8" textAnchor="middle">Tb</text>
        <line x1={px+(sz.Tc/4)*cw} y1={py} x2={px+(sz.Tc/4)*cw} y2={py+ch} stroke="#f59e0b" strokeWidth="1" strokeDasharray="4"/>
        <text x={px+(sz.Tc/4)*cw} y={py-4} fill="#f59e0b" fontSize="9" textAnchor="middle">Tc={sz.Tc}s</text>
        <line x1={px+(2/4)*cw} y1={py} x2={px+(2/4)*cw} y2={py+ch} stroke="#94a3b8" strokeWidth="1" strokeDasharray="2"/>
        <text x={px+(2/4)*cw} y={py-4} fill="#94a3b8" fontSize="8" textAnchor="middle">Td=2s</text>
      </svg>
    );
  };

  const tabs=[
    {id:"project",label:"Proiect",icon:<Ic.Building/>},{id:"permanent",label:"G",icon:<Ic.Layers/>},
    {id:"snow",label:"Zapada",icon:<Ic.Snow/>},{id:"wind",label:"Vant",icon:<Ic.Wind/>},
    {id:"seismic",label:"Seismic",icon:<Ic.Seismic/>},{id:"combo",label:"Combinatii",icon:<Ic.Combo/>}
  ];

  const rProject = () => (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <Card title="Date Generale" accent="#3b82f6">
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <Inp label="Denumire proiect" value={proj.name} onChange={(v:any)=>setProj((p:any)=>({...p,name:v}))}/>
          <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
            <Sel label="Judet" value={proj.judet} onChange={(v:any)=>setProj((p:any)=>({...p,judet:v}))} options={Object.keys(JUDETE_ZAPADA).map(j=>({value:j,label:j}))}/>
            <Sel label="Tip cladire" value={proj.tipCladire} onChange={(v:any)=>setProj((p:any)=>({...p,tipCladire:v}))} options={[{value:"locuinta",label:"Locuinta"},{value:"birou",label:"Birouri"},{value:"comercial",label:"Comercial"},{value:"industrial",label:"Industrial"},{value:"educatie",label:"Educatie"},{value:"sanatate",label:"Sanatate"}]}/>
            <Sel label="Clasa importanta" value={proj.clasaImp} onChange={(v:any)=>setProj((p:any)=>({...p,clasaImp:v}))} options={CLS_IMP.map(c=>({value:c.cls,label:`${c.cls} - ${c.desc}`}))}/>
          </div>
        </div>
      </Card>
      <Card title="Geometrie" accent="#8b5cf6">
        <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
          <Inp label="H" value={proj.H} onChange={(v:any)=>setProj((p:any)=>({...p,H:v}))} type="number" suffix="m" small/>
          <Inp label="L" value={proj.L} onChange={(v:any)=>setProj((p:any)=>({...p,L:v}))} type="number" suffix="m" small/>
          <Inp label="B" value={proj.B} onChange={(v:any)=>setProj((p:any)=>({...p,B:v}))} type="number" suffix="m" small/>
          <Inp label="Nr.etaje" value={proj.nrEtaje} onChange={(v:any)=>setProj((p:any)=>({...p,nrEtaje:v}))} type="number" small/>
        </div>
      </Card>
      <Card title="Parametri Zonali (automat)" accent="#10b981">
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:12}}>
          {[{l:"Zapada s0k",v:`${s0k} kN/m\u00b2`,c:"#38bdf8"},{l:"Vant qb",v:`${qb} kN/m\u00b2`,c:"#a78bfa"},{l:"Seismic ag",v:`${sz.ag}g`,c:"#f87171"},{l:"Tc",v:`${sz.Tc}s`,c:"#fbbf24"},{l:"Ref.",v:sz.oras||proj.judet,c:"#fb923c"},{l:"gI",v:String(gI),c:"#34d399"}].map(i=>(
            <div key={i.l} style={{background:"#0f172a",borderRadius:8,padding:12,borderLeft:`3px solid ${i.c}`}}>
              <div style={{fontSize:11,color:"#94a3b8"}}>{i.l}</div>
              <div style={{fontSize:18,fontWeight:700,color:i.c}}>{i.v}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );

  const rPerm = () => (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <Card title="Straturi Constructive" accent="#f59e0b">
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {layers.map((l,i)=>(
            <div key={l.id} style={{display:"flex",gap:8,alignItems:"end",background:"#0f172a",padding:10,borderRadius:8}}>
              <Sel label={i===0?"Material":undefined} value={l.material} onChange={(v:any)=>{const m=MATS.find(x=>x.name===v);setLayers(p=>p.map((ll,ii)=>ii===i?{...ll,material:v,density:m?.density||ll.density,unit:m?.unit||ll.unit}:ll));}} options={MATS.map(m=>({value:m.name,label:m.name}))}/>
              <Inp label={i===0?"Densitate":undefined} value={l.density} type="number" onChange={(v:any)=>setLayers(p=>p.map((ll,ii)=>ii===i?{...ll,density:v}:ll))} suffix={l.unit} small/>
              {l.unit==="kN/m\u00b3"&&<Inp label={i===0?"Grosime":undefined} value={l.thickness} type="number" onChange={(v:any)=>setLayers(p=>p.map((ll,ii)=>ii===i?{...ll,thickness:v}:ll))} suffix="m" small/>}
              <div style={{display:"flex",flexDirection:"column",alignItems:"center",minWidth:60}}>
                {i===0&&<label style={{fontSize:11,color:"#94a3b8",fontWeight:500}}>g</label>}
                <span style={{fontSize:14,fontWeight:600,color:"#fbbf24",padding:"8px 0"}}>{(l.unit==="kN/m\u00b2"?l.density:l.density*l.thickness).toFixed(2)}</span>
              </div>
              <Btn variant="danger" small onClick={()=>setLayers(p=>p.filter((_,ii)=>ii!==i))}><Ic.Trash/></Btn>
            </div>
          ))}
          <Btn variant="ghost" onClick={()=>setLayers(p=>[...p,{id:"l"+Date.now(),material:"Beton armat",density:25,thickness:0.1,unit:"kN/m\u00b3"}])}><Ic.Plus/> Adauga strat</Btn>
        </div>
      </Card>
      <div style={{background:"#0f172a",borderRadius:10,padding:20,textAlign:"center",border:"2px solid #f59e0b"}}>
        <div style={{fontSize:12,color:"#94a3b8",marginBottom:4}}>TOTAL G</div>
        <div style={{fontSize:32,fontWeight:800,color:"#fbbf24"}}>{totalG.toFixed(2)} <span style={{fontSize:16}}>kN/m\u00b2</span></div>
      </div>
    </div>
  );

  const rSnow = () => (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <Card title="Zapada - CR 1-1-3/2012" accent="#38bdf8">
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
            <div style={{flex:1,background:"#0f172a",borderRadius:8,padding:12}}>
              <div style={{fontSize:11,color:"#94a3b8"}}>s0k ({proj.judet})</div>
              <div style={{fontSize:24,fontWeight:700,color:"#38bdf8"}}>{s0k} kN/m\u00b2</div>
            </div>
            <Sel label="Tip acoperis" value={sP.roofType} onChange={(v:any)=>{const mu:any={plat:0.8,simpanta:0.8,dubla:0.8,shed:0.6};setSP(p=>({...p,roofType:v,mu:mu[v]||0.8}));}} options={[{value:"plat",label:"Plat"},{value:"simpanta",label:"Monopanta"},{value:"dubla",label:"Doua ape"},{value:"shed",label:"Shed"}]}/>
          </div>
          <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
            <Inp label="\u03bci" value={sP.mu} onChange={(v:any)=>setSP(p=>({...p,mu:v}))} type="number" small/>
            <Inp label="Ce" value={sP.Ce} onChange={(v:any)=>setSP(p=>({...p,Ce:v}))} type="number" small/>
            <Inp label="Ct" value={sP.Ct} onChange={(v:any)=>setSP(p=>({...p,Ct:v}))} type="number" small/>
          </div>
        </div>
      </Card>
      <div style={{background:"#0f172a",borderRadius:10,padding:20,textAlign:"center",border:"2px solid #38bdf8"}}>
        <div style={{fontSize:12,color:"#94a3b8",marginBottom:4}}>s = \u03bci \u00d7 Ce \u00d7 Ct \u00d7 s0k = {sP.mu} \u00d7 {sP.Ce} \u00d7 {sP.Ct} \u00d7 {s0k}</div>
        <div style={{fontSize:32,fontWeight:800,color:"#38bdf8"}}>{snowL.toFixed(2)} <span style={{fontSize:16}}>kN/m\u00b2</span></div>
      </div>
    </div>
  );

  const rWind = () => (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <Card title="Vant - CR 1-1-4/2012" accent="#a78bfa">
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
            <div style={{flex:1,background:"#0f172a",borderRadius:8,padding:12}}>
              <div style={{fontSize:11,color:"#94a3b8"}}>qb ({proj.judet})</div>
              <div style={{fontSize:24,fontWeight:700,color:"#a78bfa"}}>{qb} kN/m\u00b2</div>
            </div>
            <Sel label="Cat. teren" value={wP.catTeren} onChange={(v:any)=>setWP(p=>({...p,catTeren:v}))} options={CAT_TEREN.map(c=>({value:c.cat,label:`${c.cat} - ${c.desc}`}))}/>
          </div>
          <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
            <Inp label="co(z)" value={wP.co} onChange={(v:any)=>setWP(p=>({...p,co:v}))} type="number" small/>
            <div style={{flex:1,background:"#0f172a",borderRadius:8,padding:12}}>
              <div style={{fontSize:11,color:"#94a3b8"}}>z0={tc.z0}m | zmin={tc.zmin}m | kr={kr.toFixed(4)}</div>
              <div style={{fontSize:11,color:"#94a3b8"}}>cr(z)={crz.toFixed(4)} la z={zz.toFixed(1)}m</div>
            </div>
          </div>
        </div>
      </Card>
      <div style={{background:"#0f172a",borderRadius:10,padding:20,textAlign:"center",border:"2px solid #a78bfa"}}>
        <div style={{fontSize:12,color:"#94a3b8",marginBottom:4}}>qp(z)</div>
        <div style={{fontSize:32,fontWeight:800,color:"#a78bfa"}}>{qpz.toFixed(3)} <span style={{fontSize:16}}>kN/m\u00b2</span></div>
      </div>
    </div>
  );

  const rSeismic = () => (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <Card title="Seismic - P100-1/2013" accent="#ef4444">
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <div style={{background:"#0f172a",borderRadius:8,padding:10,border:"1px solid #334155"}}>
            <div style={{fontSize:11,color:"#94a3b8"}}>Localitate: <strong style={{color:"#f1f5f9"}}>{sz.oras}</strong> (jud. {proj.judet})</div>
            <div style={{fontSize:10,color:"#64748b",marginTop:4}}>P100-1/2013 | IMR=225 ani | 20% prob. depasire in 50 ani</div>
            <div style={{fontSize:10,color:"#f59e0b",marginTop:4}}>\u26a0 Valori pt. resedinta de judet. Consultati harta CCERS/UTCB pt. alte localitati.</div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(130px,1fr))",gap:12}}>
            {[{l:"ag",v:`${sz.ag}g`,c:"#f87171",d:"Acceleratie teren"},{l:"Tc",v:`${sz.Tc}s`,c:"#fbbf24",d:"Perioada colt"},{l:"gI",v:String(gI),c:"#34d399",d:"Factor importanta"},{l:"Sd,max",v:`${(sz.ag*eP.beta0*gI/eP.q).toFixed(3)}g`,c:"#f472b6",d:"Spectru proiectare"}].map(i=>(
              <div key={i.l} style={{background:"#0f172a",borderRadius:8,padding:12,borderLeft:`3px solid ${i.c}`}}>
                <div style={{fontSize:11,color:"#94a3b8"}}>{i.l}</div>
                <div style={{fontSize:20,fontWeight:700,color:i.c}}>{i.v}</div>
                <div style={{fontSize:9,color:"#475569"}}>{i.d}</div>
              </div>
            ))}
          </div>
          <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
            <Inp label="q" value={eP.q} onChange={(v:any)=>setEP(p=>({...p,q:v}))} type="number" small/>
            <Inp label="\u03b7" value={eP.eta} onChange={(v:any)=>setEP(p=>({...p,eta:v}))} type="number" small/>
            <Inp label="\u03b2\u2080" value={eP.beta0} onChange={(v:any)=>setEP(p=>({...p,beta0:v}))} type="number" small/>
          </div>
        </div>
      </Card>
      <Card title="Spectru Elastic Se(T)"><Spectrum/>
        <div style={{fontSize:10,color:"#64748b",marginTop:8}}>Tb={( sz.Tc/3).toFixed(2)}s | Tc={sz.Tc}s | Td=2.0s | Se,max={(sz.ag*eP.beta0*eP.eta*gI).toFixed(3)}g</div>
      </Card>
    </div>
  );

  const rCombo = () => {
    const sec = (title:string,items:any[],accent:string,clr:string) => (
      <Card title={title} accent={accent}>
        {items.map((c:any,i:number)=>(
          <div key={i} style={{background:"#0f172a",borderRadius:8,padding:12,marginBottom:8,borderLeft:`3px solid ${accent}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
              <div><div style={{fontSize:13,fontWeight:600,color:"#f1f5f9"}}>{c.name}</div>
                <div style={{fontSize:11,color:"#64748b",fontFamily:"monospace",marginTop:2}}>{c.formula}</div></div>
              <div style={{fontSize:20,fontWeight:700,color:clr}}>{c.value.toFixed(2)} <span style={{fontSize:12}}>kN/m\u00b2</span></div>
            </div>
          </div>
        ))}
      </Card>
    );
    return (
      <div style={{display:"flex",flexDirection:"column",gap:16}}>
        {sec("Combinatii ULS - EN 1990 (STR/GEO)",combos.uls,"#ef4444","#f87171")}
        {sec("Combinatii SLS - Frecventa",combos.sls_f,"#3b82f6","#60a5fa")}
        {sec("SLS - Quasi-permanenta",combos.sls_q,"#10b981","#34d399")}
        <Btn variant="success" onClick={exportR} style={{alignSelf:"flex-start"}}><Ic.Dl/> Exporta raport .txt</Btn>
      </div>
    );
  };

  const cm:any = {project:rProject,permanent:rPerm,snow:rSnow,wind:rWind,seismic:rSeismic,combo:rCombo};

  return (
    <div style={{background:"#0f172a",minHeight:"100vh",color:"#e2e8f0",fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif"}}>
      <div style={{background:"#1e293b",borderBottom:"1px solid #334155",padding:"12px 20px",display:"flex",alignItems:"center",gap:12,flexWrap:"wrap"}}>
        <div style={{width:32,height:32,background:"linear-gradient(135deg,#3b82f6,#8b5cf6)",borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:14}}>SC</div>
        <div><div style={{fontWeight:700,fontSize:16}}>StructCalc</div>
          <div style={{fontSize:11,color:"#64748b"}}>Evaluare incarcari | EN 1991 / P100-1/2013 / CR 1-1-3 / CR 1-1-4</div></div>
        {proj.name&&<Badge color="#3b82f6">{proj.name}</Badge>}
      </div>
      <div style={{background:"#1e293b",borderBottom:"1px solid #334155",display:"flex",overflowX:"auto",padding:"0 12px"}}>
        {tabs.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{background:"none",border:"none",color:tab===t.id?"#3b82f6":"#94a3b8",padding:"10px 14px",fontSize:12,fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:6,whiteSpace:"nowrap",borderBottom:tab===t.id?"2px solid #3b82f6":"2px solid transparent",transition:"all 0.15s"}}>{t.icon} {t.label}</button>
        ))}
      </div>
      <div style={{padding:16,maxWidth:900,margin:"0 auto"}}>{cm[tab]?.()}</div>
      <div style={{textAlign:"center",padding:"16px 0",fontSize:10,color:"#475569"}}>StructCalc v1.0 | P100-1/2013 (resedinte judet) | Caracter informativ</div>
    </div>
  );
}