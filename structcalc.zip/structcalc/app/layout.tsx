import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "StructCalc \u2014 Evaluare \u00cenc\u0103rc\u0103ri Structurale",
  description: "Calculator online pentru \u00eenc\u0103rc\u0103ri structurale conform normativelor rom\u00e2ne\u0219ti: P100-1/2013 (seismic), CR 1-1-3/2012 (z\u0103pad\u0103), CR 1-1-4/2012 (v\u00e2nt), EN 1990 (combina\u021bii).",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ro">
      <body style={{ margin: 0, padding: 0 }}>{children}</body>
    </html>
  );
}